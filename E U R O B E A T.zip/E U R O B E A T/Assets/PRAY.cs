﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class PRAY : MonoBehaviour
{
    // Start is called before the first frame update
    private Rigidbody2D rb;
    private Camera cam;
    public bool canMove;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        cam = Camera.main;
        canMove = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (canMove)
        {
            float mouseX = Input.GetAxis("Mouse X");
            float mouseY = Input.GetAxis("Mouse Y");
        
            rb.transform.position = cam.ScreenToWorldPoint(Input.mousePosition);
            rb.transform.position = new Vector3(rb.transform.position.x, rb.transform.position.y, 0);
            
        }

        if (Input.GetMouseButtonDown(0))
        {
            // Put the sticker
            // Set the position to this location
            // Remove the movability of this sticker
            canMove = false;
        }
    }
}
