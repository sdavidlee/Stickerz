﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BackgroundChange : MonoBehaviour
{
    public Button button;
    public Sprite[] backgrounds;
    private SpriteRenderer renderer;

    private int pos;
    // Start is called before the first frame update
    void Start()
    {
        renderer = GetComponent<SpriteRenderer>();
        button.onClick.AddListener(TaskOnClick);
    }

    // Update is called once per frame
    void TaskOnClick()
    {
        pos++;
        if (pos >= backgrounds.Length)
        {
            pos = 0;
        }
        renderer.sprite = backgrounds[pos];
    }
}
