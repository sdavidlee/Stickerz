﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IterateList : MonoBehaviour
{
    public GameObject[] stickers;

    private int pos = 0;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            pos++;
            if (pos >= stickers.Length)
            {
                pos = 0;
            }
        }
        
        if (Input.GetKeyDown(KeyCode.Z))
        {
            if (stickers[pos].GetComponent<PRAY>().canMove)
                stickers[pos].SetActive(false);
            if (pos >= 1)
                pos--;
            else
                pos = stickers.Length - 1;
        }
        else if (Input.GetKeyDown(KeyCode.X))
        {
            if (stickers[pos].GetComponent<PRAY>().canMove)
                stickers[pos].SetActive(false);
            if (pos + 1 < stickers.Length)
                pos++;
            else
                pos = 0;
        }
        stickers[pos].SetActive(true);
    }
}
